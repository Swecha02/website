import React from 'react';
import { Helmet } from 'react-helmet';
import HeroSection from '@/components/home/HeroSection';
import ProductCategories from '@/components/home/ProductCategories';
import CustomerLogos from '@/components/home/CustomerLogos';
import WhyChooseUs from '@/components/home/WhyChooseUs';
import CTASection from '@/components/home/CTASection';

const HomePage = ({ onGetQuoteClick }) => {
  return (
    <>
      <Helmet>
        <title>Swecha Enterprises - Leading Physiotherapy & Rehabilitation Equipment Distributor</title>
        <meta name="description" content="Swecha Enterprises offers premium physiotherapy and rehabilitation equipment with 7 years of excellence. Partner with us for quality medical equipment solutions." />
      </Helmet>
      <div>
        <HeroSection onGetQuoteClick={onGetQuoteClick} />
        <ProductCategories />
        <CustomerLogos />
        <WhyChooseUs />
        <CTASection onGetQuoteClick={onGetQuoteClick} />
      </div>
    </>
  );
};

export default HomePage;