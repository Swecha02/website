import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Award, Target, Eye, Users, TrendingUp, Heart } from 'lucide-react';
const AboutPage = () => {
  return <>
      <Helmet>
        <title>About Us - Swecha Enterprises | 7 Years of Excellence</title>
        <meta name="description" content="Learn about Swecha Enterprises' 7-year journey in providing quality physiotherapy and rehabilitation equipment. Partnered with Monarc Distribution Network." />
      </Helmet>

      <div className="min-h-screen">
        <section className="bg-gradient-to-br from-[#0C3B78] to-[#0c3b78e0] text-white py-20">
          <div className="container mx-auto px-4">
            <motion.div initial={{
            opacity: 0,
            y: 30
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6
          }} className="max-w-4xl mx-auto text-center">
              <h1 className="text-5xl md:text-6xl font-bold mb-6">About Swecha Enterprises</h1>
              <p className="text-xl text-gray-200">
                Your trusted partner in physiotherapy and rehabilitation equipment with a legacy of excellence
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <motion.div initial={{
              opacity: 0,
              x: -50
            }} whileInView={{
              opacity: 1,
              x: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6
            }}>
                <h2 className="text-4xl font-bold text-[#0C3B78] mb-6">Our Journey</h2>
                <p className="text-lg text-gray-700 mb-4 leading-relaxed">Started journey in 2017, Swecha Enterprises has consistently evolved to meet the changing needs of the healthcare industry. Our journey began with a clear vision: to be a trusted source of cutting-edge physiotherapy and rehabilitation equipment.</p>
                <p className="text-lg text-gray-700 mb-4 leading-relaxed">Over the past 9 years, we have developed an unrivaled understanding of the sector, and our commitment to innovation and customer satisfaction has driven our growth. Our partnership with Monarc Distribution Network, with their two-decade-strong foundation in sales and network connections, has further strengthened our mission.</p>
                <p className="text-lg text-gray-700 leading-relaxed">
                  We are committed to making a positive impact on people's lives by providing high-quality equipment and solutions that promote health, well-being, and recovery.
                </p>
              </motion.div>

              <motion.div initial={{
              opacity: 0,
              x: 50
            }} whileInView={{
              opacity: 1,
              x: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6
            }} className="relative">
                <img alt="Swecha Enterprises team and facility" className="rounded-2xl shadow-2xl w-full" src="https://horizons-cdn.hostinger.com/a8b98c05-7e5d-4636-bdce-2ee1762d8e20/gemini_generated_image_2nvrtx2nvrtx2nvr-LJskB.png" />
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
              <motion.div initial={{
              opacity: 0,
              y: 30
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6
            }} className="bg-white rounded-2xl p-8 shadow-lg">
                <div className="w-16 h-16 bg-[#499D46] rounded-full flex items-center justify-center mb-6">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-[#0C3B78] mb-4">Our Mission</h3>
                <p className="text-gray-700 leading-relaxed">
                  To provide healthcare professionals and facilities with the highest quality physiotherapy and rehabilitation equipment, enabling them to deliver exceptional patient care and achieve optimal recovery outcomes.
                </p>
              </motion.div>

              <motion.div initial={{
              opacity: 0,
              y: 30
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6,
              delay: 0.2
            }} className="bg-white rounded-2xl p-8 shadow-lg">
                <div className="w-16 h-16 bg-[#0C3B78] rounded-full flex items-center justify-center mb-6">
                  <Eye className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-[#0C3B78] mb-4">Our Vision</h3>
                <p className="text-gray-700 leading-relaxed">
                  To be the leading distributor of physiotherapy and rehabilitation equipment in India, recognized for our commitment to quality, innovation, and customer satisfaction, while continuously expanding our reach and impact.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <motion.div initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6
          }} className="text-center mb-16">
              <h2 className="text-4xl font-bold text-[#0C3B78] mb-4">Our Core Values</h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                The principles that guide everything we do
              </p>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {[{
              icon: Award,
              title: 'Quality Excellence',
              description: 'We never compromise on quality, ensuring every product meets the highest standards'
            }, {
              icon: Heart,
              title: 'Customer First',
              description: 'Your needs drive our decisions, and your satisfaction is our success'
            }, {
              icon: TrendingUp,
              title: 'Continuous Innovation',
              description: 'We stay ahead of industry trends to bring you the latest technology'
            }].map((value, index) => {
              const Icon = value.icon;
              return <motion.div key={index} initial={{
                opacity: 0,
                y: 30
              }} whileInView={{
                opacity: 1,
                y: 0
              }} viewport={{
                once: true
              }} transition={{
                duration: 0.6,
                delay: index * 0.1
              }} className="text-center">
                    <div className="w-20 h-20 bg-gradient-to-br from-[#499D46] to-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                      <Icon className="w-10 h-10 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-[#0C3B78] mb-3">{value.title}</h3>
                    <p className="text-gray-600">{value.description}</p>
                  </motion.div>;
            })}
            </div>
          </div>
        </section>

        <section className="py-20 bg-gradient-to-br from-[#0C3B78] to-[#0c3b78e0] text-white">
          <div className="container mx-auto px-4">
            <motion.div initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6
          }} className="max-w-4xl mx-auto text-center">
              <Users className="w-16 h-16 mx-auto mb-6 text-[#499D46]" />
              <h2 className="text-4xl font-bold mb-6">Partnership with Monarc Distribution Network</h2>
              <p className="text-xl text-gray-200 leading-relaxed">
                Our collaboration with Monarc Distribution Network brings two decades of experience in sales, distribution, and connecting people to the table. This partnership enhances our reach and allows us to serve you better, combining our specialized knowledge with their extensive network and proven track record.
              </p>
            </motion.div>
          </div>
        </section>
      </div>
    </>;
};
export default AboutPage;