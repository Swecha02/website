import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Twitter, Linkedin, Instagram } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-[#0C3B78] text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <img 
              src="https://horizons-cdn.hostinger.com/a8b98c05-7e5d-4636-bdce-2ee1762d8e20/195574b57ce7aed1362cd698446c9412.jpg" 
              alt="Swecha Enterprises" 
              className="h-16 w-auto mb-4 bg-white p-2 rounded"
            />
            <p className="text-sm text-gray-300 leading-relaxed">
              Your trusted partner in physiotherapy and rehabilitation equipment with 7 years of excellence.
            </p>
          </div>

          <div>
            <span className="text-lg font-semibold mb-4 block text-[#499D46]">Quick Links</span>
            <ul className="space-y-2">
              <li><Link to="/" className="text-sm text-gray-300 hover:text-[#499D46] transition-colors">Home</Link></li>
              <li><Link to="/about" className="text-sm text-gray-300 hover:text-[#499D46] transition-colors">About Us</Link></li>
              <li><Link to="/products" className="text-sm text-gray-300 hover:text-[#499D46] transition-colors">Products</Link></li>
              <li><Link to="/contact" className="text-sm text-gray-300 hover:text-[#499D46] transition-colors">Contact</Link></li>
            </ul>
          </div>

          <div>
            <span className="text-lg font-semibold mb-4 block text-[#499D46]">Contact Info</span>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-sm text-gray-300">
                <MapPin className="w-4 h-4 mt-1 flex-shrink-0 text-[#499D46]" />
                <span>11-3-664/238/A/29, Sajeevapuram, Parsigutta, Hyderabad, Telangana, India - 500061</span>
              </li>
              <li className="flex items-center gap-2 text-sm text-gray-300">
                <Phone className="w-4 h-4 flex-shrink-0 text-[#499D46]" />
                <a href="tel:+919885839555" className="hover:text-[#499D46] transition-colors">+91 9885839555</a>
              </li>
              <li className="flex items-center gap-2 text-sm text-gray-300">
                <Mail className="w-4 h-4 flex-shrink-0 text-[#499D46]" />
                <a href="mailto:contact@yourswecha.com" className="hover:text-[#499D46] transition-colors">contact@yourswecha.com</a>
              </li>
            </ul>
          </div>

          <div>
            <span className="text-lg font-semibold mb-4 block text-[#499D46]">Follow Us</span>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-[#499D46] transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-[#499D46] transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-[#499D46] transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-[#499D46] transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-8 pt-8 text-center">
          <p className="text-sm text-gray-300">
            © {new Date().getFullYear()} Swecha Enterprises. All rights reserved. | Powered by Monarc Distribution Network
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;