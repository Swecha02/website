import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const HeroSection = ({ onGetQuoteClick }) => {
  const navigate = useNavigate();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Appended new images to the existing carousel images
  const images = [
    // Existing images
    { src: "https://horizons-cdn.hostinger.com/a8b98c05-7e5d-4636-bdce-2ee1762d8e20/5e230eeb6bada6aa2e053c300b17c2aa.png", alt: "Advanced physiotherapy knee treatment" },
    { src: "https://horizons-cdn.hostinger.com/a8b98c05-7e5d-4636-bdce-2ee1762d8e20/4da7adbe7c77e8a3e4b510ec13571a3b.png", alt: "Patient lift system with caregiver" },
    { src: "https://horizons-cdn.hostinger.com/a8b98c05-7e5d-4636-bdce-2ee1762d8e20/377aaa754ad7836de34b8f6a1b7748b0.png", alt: "Touchscreen medical interface device" },
    { src: "https://horizons-cdn.hostinger.com/a8b98c05-7e5d-4636-bdce-2ee1762d8e20/1d4dc214f59810fa5565636adbb82976.png", alt: "Interactive movement therapy room" },
    { src: "https://horizons-cdn.hostinger.com/a8b98c05-7e5d-4636-bdce-2ee1762d8e20/bfee2c846dcd6f6bee7b38796446db8f.png", alt: "Robotic gait training system" },
    // New uploaded images
    { src: "https://horizons-cdn.hostinger.com/a8b98c05-7e5d-4636-bdce-2ee1762d8e20/eac901e65b6bef09d649bc3e5575cf49.png", alt: "Hydrotherapy rehabilitation tub system" },
    { src: "https://horizons-cdn.hostinger.com/a8b98c05-7e5d-4636-bdce-2ee1762d8e20/38463a2b11ef98c30b0788d818f96e77.png", alt: "Suspension therapy cage system" },
    { src: "https://horizons-cdn.hostinger.com/a8b98c05-7e5d-4636-bdce-2ee1762d8e20/abc34a29a88ab4103a6bd04dac72366f.png", alt: "Hand therapy and fine motor skills table" },
    { src: "https://horizons-cdn.hostinger.com/a8b98c05-7e5d-4636-bdce-2ee1762d8e20/80a5f476c04685c67b0eb22cf4854aa4.png", alt: "Rehabilitation driving simulator" },
    { src: "https://horizons-cdn.hostinger.com/a8b98c05-7e5d-4636-bdce-2ee1762d8e20/612b73d477abb73d6a2e1da2bcbecf20.png", alt: "Mobile patient lift hoist" },
    { src: "https://horizons-cdn.hostinger.com/a8b98c05-7e5d-4636-bdce-2ee1762d8e20/d6de68c7e9e511773fc0e1eee45932aa.png", alt: "Adjustable electric treatment table" }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % images.length);
    }, 2000); 

    return () => clearInterval(interval);
  }, [images.length]);

  return (
    <section className="relative h-[80vh] flex items-center justify-center text-center overflow-hidden">
      {/* Carousel Container */}
      <div className="absolute inset-0">
        
        {images.map((image, index) => (
          <motion.div 
            key={index}
            className="absolute inset-0"
            initial={{ opacity: 0 }}
            animate={{ opacity: currentImageIndex === index ? 1 : 0 }}
            transition={{ duration: 0.8 }}
          >
            <img 
              className="w-full h-full object-cover" 
              alt={image.alt} 
              src={image.src} 
            />
          </motion.div>
        ))}

        {/* Overlay */}
        <div className="absolute inset-0 bg-black opacity-60 z-10"></div>
      </div>

      {/* Content */}
      <div className="relative z-20 text-white max-w-4xl mx-auto px-4">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl md:text-7xl font-bold mb-6 leading-tight"
        >
          <span className="text-balance">Empowering Recovery, Enhancing Life</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-lg md:text-xl mb-8 max-w-2xl mx-auto"
        >
          Your trusted partner for premium physiotherapy and rehabilitation equipment.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex flex-col sm:flex-row justify-center gap-4"
        >
          <Button
            size="lg"
            className="bg-[#499D46] hover:bg-green-700 text-white font-semibold shadow-lg hover:shadow-xl transition-all"
            onClick={() => onGetQuoteClick('Hero Section Quote Request')}
          >
            Get a Quote
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
          <Button
            size="lg"
            className="bg-[#0C3B78] hover:bg-[#499D46] text-white font-semibold shadow-lg hover:shadow-xl transition-all"
            onClick={() => window.location.href = 'tel:+919885839555'} // Added phone link to Contact Us button
          >
            Contact Us
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;