import pg from 'pg';
import 'dotenv/config';

const { Pool } = pg;

export const pool = new Pool({
  host: process.env.PGHOST || 'localhost',
  port: process.env.PGPORT || 5432,
  user: process.env.PGUSER,
  password: process.env.PGPASSWORD,
  database: process.env.PGDATABASE,
  max: 5, // KVM 2 has limited RAM/connections - keep this modest
});

pool.on('error', (err) => {
  console.error('Unexpected Postgres pool error:', err);
});
